import { cookies } from 'next/headers';
import type { ReactNode } from 'react';
import StyledRegistry from '../../shared/styledRegistry';
import { ThemeProvider } from '../../context/ThemeContext';
import { getDirection } from '../../utils/getDirection';
import { parseThemeMode } from '../../utils/parseThemeMode';
import { THEME_COOKIE } from '../../utils/constants/theme';
// import { vazirmatn } from '...'   ← فونت خودت

interface LocaleLayoutProps {
    children: ReactNode;
    params: Promise<{ locale: string }>;
}

export default async function LocaleLayout({ children, params }: LocaleLayoutProps) {
    const { locale } = await params;
    const cookieStore = await cookies();
    const initialMode = parseThemeMode(cookieStore.get(THEME_COOKIE)?.value);

    return (
        <html lang={locale} dir={getDirection(locale)}>
            <body /* className={vazirmatn.variable} */>
                <StyledRegistry>
                    <ThemeProvider initialMode={initialMode}>{children}</ThemeProvider>
                </StyledRegistry>
            </body>
        </html>
    );
}