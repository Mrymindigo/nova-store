import SmokeTest from '../../components/header/smokeTest/index';

export default function HomePage() {
  return <SmokeTest />;
}