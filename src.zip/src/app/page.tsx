// import Image from "next/image";
// import styles from "./page.module.css";


// export default function Home() {
//   return (
//    <>
//    nova store
//    </>
//   );
// }

import SmokeTest from '../components/header/smokeTest/index';

export default function HomePage() {
  return <SmokeTest />;
}