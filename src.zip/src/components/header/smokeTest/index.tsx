'use client';

import styled from 'styled-components';
import { useThemeMode } from '../../../context/ThemeContext';

const Card = styled.div`
  max-width: 420px;
  margin: 3rem auto;
  padding: 1.5rem;
  background: ${({ theme }) => theme.colors.secondary};
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: ${({ theme }) => theme.radius.lg};
  box-shadow: ${({ theme }) => theme.shadow.card};
`;

const Button = styled.button`
  margin-top: 1rem;
  padding: 0.6rem 1.25rem;
  color: #ffffff;
  background: ${({ theme }) => theme.colors.accent};
  border: none;
  border-radius: ${({ theme }) => theme.radius.md};

  &:hover {
    background: ${({ theme }) => theme.colors.accentHover};
  }
`;

export default function SmokeTest() {
    const { mode, toggleMode } = useThemeMode();

    return (
        <Card>
            <h1>سلام NOVA ۱۲۳ Hello 456</h1>
            <p>Theme: {mode}</p>
            <Button type="button" onClick={toggleMode}>
                Toggle theme
            </Button>
        </Card>
    );
}